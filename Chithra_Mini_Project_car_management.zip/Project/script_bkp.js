var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function myFunction() {
  //alert("rfgrfg");
  debugger;
  var book_now = document.getElementsByClassName('book_now')[0].style.display='block';
    //document.getElementById('id02').style.display='block';
  }

  $( "#submit_Contact" ).click(function() {
    var Contact_name = $('#c_name').val();
     var Contact_email = $('#email').val();
     var Contact_subject = $('#subject').val();
     
     $(".error").remove();
     
     if (Contact_name.length < 1) {
       $('#c_name').after('<span class="error"></br>This field is required.</br></span>');
     }else {
      var testName = /^([a-zA-Z]{3,16})$/;
      if (!testName.test(Contact_name))
        $('#c_name').after('<span class="error">Enter a valid Name.<br/></span>');
    
  }
   if(Contact_subject.length < 1){
   $('#subject').after('<span class="error"></br>This field is required.</br></span>');
   }
   
    
    if (Contact_email.length < 1) {
      $('#email').after('<span class="error">This field is required.<br/></span>');
    } else {
     
      var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
      if (!testEmail.test(Contact_email))
        $('#email').after('<span class="error">Enter a valid email.<br/></span>');
    
  }
   
 
 });
 $( "#submit_Signup" ).click(function() {
  var Signup_name = $('#s_name').val();
   var Contact_email = $('#s_email').val();
   var Contact_subject = $('#emp_Id').val();
   var signup_Password =$('#password').val();

   $(".error").remove();

   if (Signup_name.length < 1) {
     $('#s_name').after('<span class="error"></br>This field is required.</br></span>');
   }else {
    var testName = /^([a-zA-Z ]{3,16})$/;
    if (!testName.test(Signup_name))
      $('#s_name').after('<span class="error">Enter a valid Name.<br/></span>');
  
}
 
 if(Contact_subject.length < 1){
 $('#emp_Id').after('<span class="errorThis field is required.</br></span>');
 }
 
  // Below code is used to validate email
  if (Contact_email.length < 1) {
    $('#s_email').after('<span class="error">This field is required.<br/></span>');
  } else {
   
    var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
    if (!testEmail.test(Contact_email))
   
      $('#s_email').after('<span class="error">Enter a valid email.<br/></span>');
  
}
if (signup_Password.length < 1) {
  $('#password').after('<span class="error">This field is required.<br/></span>');
} else {
if ($('#password').val() != $('#confirmPassword').val()) {
  $('#confirmPassword').after('<span class="error">The password and confirmation password do not match.<br/></span>');
}
}
 
  
});


  
function productList() {
  // Call Web API to get a list of Product
  $.ajax({
    url: 'http://localhost:3000/contacts',
    type: 'POST',
    dataType: 'json',
    success: function (products) {
      productListSuccess(products);
    },
    error: function (request, message, error) {
      alert("hi");
      // handleException(request, message, error);
    }
  });
}